keyboard = {
    ürün:'klavye',
    name: 'gamer',
    feature: {
        aydınlatma: 'var',
        bağlantı: 'kablolu',
        tip:'mekanik',
        RGB:'var',
        Dil:'Türkçe(Q)'
    },
    price:'525TL'
    
    
}
keyboard2 = {
    ürün:'klavye',
    name: 'Logitech',
    feature: {
        aydınlatma: 'yok',
        bağlantı: 'kablosuz',
        tip:'mekanik',
        RGB:'yok',
        Dil:'Türkçe(Q)'
    },
    price:'300TL'
    
    
}
keyboard3= {
    ürün:'klavye',
    name: 'Performax',
    feature: {
        aydınlatma: 'yok',
        bağlantı: 'kablolu',
        tip:'mekanik',
        RGB:'vyok',
        Dil:'Türkçe(Q)'
    },
    price:'150TL'
    
    
}


function showUser(value) {

    document.querySelector('.ürün').innerHTML +=`
    ürün: ${keyboard.ürün}
    `

    document.querySelector('.name').innerHTML += `
        isim: ${keyboard.name}
    
    `   
    document.querySelector('.feature').innerHTML += `
    <span>aydınlatma: ${keyboard.feature.aydınlatma}</span>
    <span>bağlantı: ${keyboard.feature.bağlantı}</span>
    <span>tip: ${keyboard.feature.tip}</span>
    <span>RGB: ${keyboard.feature.RGB}</span>
    <span>Dil: ${keyboard.feature.Dil}</span>

`

    document.querySelector('.price').innerHTML += `
     ücret: ${keyboard.price}

`

   

    document.getElementById("btn").disabled = true;
}

function showUser2(value) {

    document.querySelector('.ürün').innerHTML +=`
    ürün: ${keyboard2.ürün}
    `

    document.querySelector('.name').innerHTML += `
        isim: ${keyboard2.name}
    
    `   
    document.querySelector('.feature').innerHTML += `
    <span>aydınlatma: ${keyboard2.feature.aydınlatma}</span>
    <span>bağlantı: ${keyboard2.feature.bağlantı}</span>
    <span>tip: ${keyboard2.feature.tip}</span>
    <span>RGB: ${keyboard2.feature.RGB}</span>
    <span>Dil: ${keyboard2.feature.Dil}</span>

`

    document.querySelector('.price').innerHTML += `
     ücret: ${keyboard2.price}

`

   

    document.getElementById("btn2").disabled = true;
}


function showUser3(value) {

    document.querySelector('.ürün').innerHTML +=`
    ürün: ${keyboard3.ürün}
    `

    document.querySelector('.name').innerHTML += `
        isim: ${keyboard3.name}
    
    `   
    document.querySelector('.feature').innerHTML += `
    <span>aydınlatma: ${keyboard3.feature.aydınlatma}</span>
    <span>bağlantı: ${keyboard3.feature.bağlantı}</span>
    <span>tip: ${keyboard3.feature.tip}</span>
    <span>RGB: ${keyboard3.feature.RGB}</span>
    <span>Dil: ${keyboard3.feature.Dil}</span>

`

    document.querySelector('.price').innerHTML += `
     ücret: ${keyboard3.price}

`

   

    document.getElementById("btn3").disabled = true;
}

